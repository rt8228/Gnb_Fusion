import smtplib,ssl
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from config_read import configRead
from datetime import date,datetime
to = configRead('toemails')
fromemail = configRead('fromemail')
sub = configRead('subject')
server = configRead('mailserver')
body = configRead('body')
msg = MIMEMultipart()
msg['To'] = to
msg['Date'] = formatdate(localtime=True)
msg['Subject'] = sub
text = 'Hi\n' + body + '\n' + 'http://' + configRead('host') + ':' + configRead('port_for_report') + '/' + str(
        date.today())
msg.attach(MIMEText(text))
smtp = smtplib.SMTP(server)

d = smtp.sendmail(fromemail, to.split(','), msg.as_string())
smtp.quit()
print("mail sent successfully")
# except Exception as e:
#   print(e)

