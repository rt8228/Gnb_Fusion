import graph as gr
import os

if __name__ == '__main__':
    print(os.getcwd())
    gr.graphRun2()
    gr.graphRun1()