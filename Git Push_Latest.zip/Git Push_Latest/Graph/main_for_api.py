import os,shutil
import urllib.request
try:
	from Graph.app_for_api import app1
	from Graph.config_read import configRead
except ModuleNotFoundError :
	from  app_for_api import app1
	from config_read import configRead
from flask import Flask, request, redirect, jsonify
from werkzeug.utils import secure_filename
from datetime import date,datetime
import json
import time
import atexit
from apscheduler.schedulers.background import BackgroundScheduler
import ctypes  # An included library with Python install.
import datetime
import calendar
import time
import pandas as pd
import smtplib,ssl
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders






ALLOWED_EXTENSIONS = set(['xlsx', 'xls'])

def sendmail():
    to=configRead('toemails')

    fromemail=configRead('fromemail')
    sub=configRead('subject')
    server=configRead('mailserver')
    body=configRead('body')
    print(to)

    try:
        msg = MIMEMultipart()
        msg['To'] = to
        msg['Date'] = formatdate(localtime=True)
        msg['Subject'] = sub
        text='Hi\n'+body+'\n'+'http://'+configRead('host')+':'+configRead('port_for_report')+'/'+str(date.today())
        msg.attach(MIMEText(text))
        smtp = smtplib.SMTP(server)

        d = smtp.sendmail(fromemail, to.split(','), msg.as_string())
        smtp.quit()
        print("mail sent successfully")
    except Exception as e:
        print(e)



def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS




def print_date_time():
	now = datetime.datetime.now()
	now1=now.strftime("%Y-%m-%d %H:%M:%S")


	my_time_string = configRead('schedular_time')
	my_time_string = now.strftime("%Y-%m-%d") + " " + my_time_string

	my_time = time.strptime(my_time_string, "%Y-%m-%d %H:%M:%S")

	my_datetime = datetime.datetime(1970, 1, 1) + datetime.timedelta(seconds=calendar.timegm(my_time))


	print(now1)
	print(my_datetime)
	if (str(now1) == str(my_datetime)):

		dirpath =os.getcwd()+'/Report/'+ str(date.today())

		allexcels = os.listdir(dirpath)
		no_excels=len(allexcels)
		df=pd.read_excel(dirpath+"\\"+allexcels[0],sheet_name='Summary Report')
		dft=pd.read_excel(dirpath+"\\"+allexcels[0],sheet_name='Defect')
		for i in range(0,no_excels-1):
			df1=pd.read_excel(dirpath+"\\"+allexcels[i+1],sheet_name='Summary Report')
			dft1=pd.read_excel(dirpath+"\\"+allexcels[i+1],sheet_name='Defect')
			df2 = pd.concat([df, df1])
			dft2=pd.concat(([dft,dft1]))
			df=df2
			dft=dft2
		# Create a Pandas Excel writer using XlsxWriter as the engine.
		writer = pd.ExcelWriter(dirpath+'\\IBMhq_Execution_Summary_Report.xlsx', engine='xlsxwriter')

		# Write each dataframe to a different worksheet.
		df.to_excel(writer,sheet_name='Summary Report')
		dft.to_excel(writer,sheet_name='Defect')


		# Close the Pandas Excel writer and output the Excel file.
		writer.save()
		shutil.copy(dirpath+'\\IBMhq_Execution_Summary_Report.xlsx',os.getcwd())
		sendmail()










@app1.before_first_request
def init_scheduler():
	scheduler = BackgroundScheduler()
	scheduler.add_job(func=print_date_time, trigger="interval", seconds=1,max_instances=30)
	scheduler.start()
	print("schedular started")
	atexit.register(lambda: scheduler.shutdown())

@app1.route('/file-upload', methods=['POST'])
def upload_file():
	print("inside req")
	print(request.headers)
	# check if the post request has the file part
	if 'file' not in request.files:
		print("file found")
		resp = jsonify({'message' : 'No file part in the request'})
		resp.status_code = 400
		return resp



	default_name = '0'
	testerName = request.form.get('testername', default_name)
	ts=request.form.get('timestamp', default_name)

	file = request.files['file']


	if file.filename == '':
		resp = jsonify({'message' : 'No file selected for uploading'})
		resp.status_code = 400
		return resp
	if file and allowed_file(file.filename):
		filename = secure_filename(file.filename)

		try:
			if (not os.path.isdir(os.path.join(app1.config['UPLOAD_FOLDER'], "Report"))):
				os.mkdir(os.path.join(app1.config['UPLOAD_FOLDER'], "Report"))
			dirpath = os.path.join(app1.config['UPLOAD_FOLDER'], "Report\\" + str(date.today()))
			if(not os.path.isdir(os.path.join(app1.config['UPLOAD_FOLDER'], "Report\\"+str(date.today())))):
				os.mkdir(dirpath)
			dir = os.listdir(dirpath)
			excelfile=os.path.join(app1.config['UPLOAD_FOLDER'], "Report\\"+str(date.today())+"\\"+testerName+"_"+ts+"_"+filename)
			if(not(excelfile in dir)):
				file.save(excelfile)
		except FileNotFoundError as e:
			print("error")
			print(e)

		resp = jsonify({'message' : 'File successfully uploaded'})
		resp.status_code = 201
		return resp
	else:
		resp = jsonify({'message' : 'Allowed file types are xlsx and xls'})
		resp.status_code = 400
		return resp

@app1.route('/mergeTodaysReport', methods=['GET'])
def mergeTodaysReport():
	dirpath = os.path.join(app1.config['UPLOAD_FOLDER'], "Report\\"+str(date.today()))
	dir = os.listdir(dirpath)
	if(os.path.isdir(dirpath) and len(dir)!=0):



		resp = jsonify({'message' : 'Report successfully merged'})
		resp.status_code = 201
		return resp
	else:
		resp = jsonify({'message' : 'No reports to merge'})
		resp.status_code = 400
		return resp

# if __name__ == "__main__":
#     app.run(port='8052')
def appRun():


	Host=configRead('host')
	Port = configRead('port_for_fileupload')
	app1.run(host=Host,port=Port,debug=False)
