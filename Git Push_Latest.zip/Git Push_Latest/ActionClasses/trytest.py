mes['ID']="abc"
mes['TEXT']="tyu"
sqlQuery= f"""INSERT INTO THL17166.WATSONDISCRESP(ID, TEXT)VALUES({id},{txt});""".format(mes['ID'],mes['TEXT'])
print(sqlQuery)